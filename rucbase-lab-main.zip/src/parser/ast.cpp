#include "ast.h"

namespace ast {

std::shared_ptr<TreeNode> parse_tree;

}
