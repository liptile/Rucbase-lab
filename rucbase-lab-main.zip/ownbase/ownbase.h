#pragma once

int ownbase_start(int argc, char **argv);